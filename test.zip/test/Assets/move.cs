﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class move : MonoBehaviour {

    public float speed;

    public Text wintext;

    public Rigidbody rb;

    public  int count;

	// Use this for initialization
	void Start () {
       

        rb = GetComponent<Rigidbody>();
        SetText();



    }
	
	// Update is called once per frame
	void FixedUpdate () {

        float a = Input.GetAxis("Horizontal");
        float b = Input.GetAxis("Vertical");

        Vector3 s = new Vector3(a, 0.0f, b);

        rb.AddForce(speed * s);
 
	}

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("block"))
        {
            other.gameObject.SetActive(false);
            count=count+1;
            SetText();

        }

    }

    void SetText()
    {
        if (count ==3)
        {
            wintext.text = " win ";
        }
    }
}
