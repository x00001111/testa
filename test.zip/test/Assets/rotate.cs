﻿using UnityEngine;
using System.Collections;

public class rotate : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

        Vector3 s = new Vector3(15, 30, 45);
        transform.Rotate(s * Time.deltaTime);
	
	}
}
